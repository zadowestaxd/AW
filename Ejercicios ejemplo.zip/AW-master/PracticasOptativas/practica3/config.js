"use strict";

module.exports = {
      host: "localhost",// Ordenador que ejecuta el SGBD
      user: "root",   // Usuario que accede a la BD
      password: "",  // Contraseña con la que se accede a la BD
      database: "tareas"  // Nombre de la base de datos
}