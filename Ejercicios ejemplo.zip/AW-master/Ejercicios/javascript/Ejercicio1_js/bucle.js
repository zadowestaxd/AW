//"use strict";

for(let k=1; k<=5; k++){
    console.log("k = " + k);
}


//-----------------------------

var x = 1;
var x = 2;

console.log(x);

delete(x);

console.log(x);

//-----------------------------
