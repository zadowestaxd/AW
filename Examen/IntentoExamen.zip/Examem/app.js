"use strict";
const path = require("path");
const express = require("express");
const { stringify } = require("querystring");
const { render } = require("ejs");
const app = express();
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.use(express.json())
app.use(express.static(path.join(__dirname, 'public')));



var usuarios = [
    {
        nombre: "Aitor", apellidos: "Tilla Patata", user: "aitor01", pass:
            "ATP01"
    },
    {
        nombre: "Carmelo", apellidos: "Cotón Partido", user: "carmelo02", pass:
            "CCP02"
    },
    {
        nombre: "Mirella", apellidos: "Baila Sola", user: "mirella03", pass:
            "MBS03"
    },
    {
        nombre: "Felipe", apellidos: "Lotas Blandas", user: "felipe04", pass:
            "FLB04"
    }
]


app.get("/", function (request, response) {

    response.render("cambio");

});
//Coge los datos nuevos al cambiar de contraseña y hace las pertinentes comprobaciones 
app.post("/cambio", function (request, response) {
    console.log(request.body);
    var v = 0;
    var con = false;
    while (v < usuarios.length && con == false) {
        if (usuarios[v].nombre == request.body.nombre) {
            con = true;
            v--;
        }
        v++;
    }
    if (con == true && request.body.oldPassword == usuarios[v].pass && usuarios[v].pass != request.body.password) {
        var cont = 0;
        var n = 0;
        while (n < request.password.length) {
            if (isUpperCasse(request.body.password.charAt(n))) {
                cont++;
            }
            n++;
        }
        if (request.body.password.length > 5 && cont > 2) {
            usuarios[v].pass = request.body.password;
            cambio.render("cambio");
        }
        else {
            console.log("fallos en la seguridad de la contraseña");
            response.render("cambio");
        }
    }
    else {
        console.log("security alert");
        response.render("cambio");
    }


});

//conecta con el servidor
app.listen(3000, function (error) {
    if (error) {
        console.log("error, no se detecta el servidor" + stringify.JSON(error));
    }
    else {
        console.log("servidor arrancado en el puerto: 3000");
    }
});